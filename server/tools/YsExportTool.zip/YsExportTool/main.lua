require 'lc'

--print(lc.help())
local cjson_open = package.loadlib('cjson.so', 'luaopen_cjson')
local cjson = cjson_open()

string.split = function(s, p)
    local rt= {}
    string.gsub(s, '[^'..p..']+', function(w) table.insert(rt, w) end )
    return rt
end

string.trim = function(s)
	return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local infile = arg[1]
local outfile = arg[2]

local file = io.open(infile, "rb")
local data = file:read("*all")
data = (lc.w2u(string.trim(data)))
data = string.sub(data, 4)
file:close()

file = io.open(outfile, "wb")
file:write(data)
file:close()

print(infile..' => '..outfile)

local items = {}
local repo = {}
local row = 0
local lines = string.split(data, '\r\n')
for _, v in pairs(lines) do
	local keys = (string.split(v, '\t'))

	row = row + 1
	if row == 1 then
		for k, s in pairs(keys) do
			local item = {}
			item.name = s
			item.type = ''
			items[k] = item
		end
	end
	if row == 2 then
		for k, s in pairs(keys) do
			items[k].type = s
		end
	end
	if row > 3 then
		local repo_row = {}
		for k, s in pairs(keys) do

			if (items[k].type == 'string') then
				repo_row[items[k].name] = s
			elseif (items[k].type == 'number') then
				repo_row[items[k].name] = tonumber(s)
			elseif (items[k].type == 'array') then
				repo_row[items[k].name] = s
			end
		end
		--print(lc.u2a(cjson.encode(keys)))
		repo[keys[1]] = repo_row
	end
end


file = io.open(arg[3], 'wb')
file:write(cjson.encode(repo))
file:close()

